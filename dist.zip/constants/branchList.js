const BRANCH_LIST = [
    {
        name: "Pusat",
        address: "Ruko Candi Bajang Ratu Kav.4 Blimbing - Malang"
    },
    {
        name: "Cabang 1",
        address: "JL. Terusan Surabaya no.16 Klojen - Malang"
    }
]

module.exports = { BRANCH_LIST };