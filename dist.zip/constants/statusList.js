const STATUS_LIST = [
    {
        name: 'Diterima'
    },
    {
        name: "Sedang dicuci"
    },
    {
        name: "Sedang disetrika"
    },
    {
        name: "Siap diambil"
    },
    {
        name: "Sudah diambil"
    }
]

module.exports = { STATUS_LIST }