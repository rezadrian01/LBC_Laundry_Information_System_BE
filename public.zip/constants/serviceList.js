const SERVICE_LIST = [
    {
        name: "Cuci Basah",
        price: 8000
    },
    {
        name: "Cuci Kering",
        price: 10000
    },
    {
        name: "Cuci Kering Setrika",
        price: 15000
    },
    {
        name: "Setrika",
        price: 7000
    },
    {
        name: "REGULER",
        price: 5000
    },
    {
        name: "EXPRESS 1",
        price: 10000
    },
    {
        name: "EXPRESS 2",
        price: 20000
    },
    {
        name: "KILAT",
        price: 3000
    },
]

module.exports = { SERVICE_LIST }