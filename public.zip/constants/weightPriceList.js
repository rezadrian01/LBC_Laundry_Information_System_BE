const WEIGHT_PRICE_LIST = [
    {
        maxWeight: 3.1,
        price: 15000
    },
    {
        maxWeight: 3.6,
        price: 18000
    },
    {
        maxWeight: 4.1,
        price: 20000
    },
    {
        maxWeight: 4.6,
        price: 23000
    },
    {
        maxWeight: 5.1,
        price: 25000
    },
    {
        maxWeight: 5.6,
        price: 28000
    },
    {
        maxWeight: 6.1,
        price: 30000
    },
    {
        maxWeight: 6.6,
        price: 33000
    },
    {
        maxWeight: 7.1,
        price: 35000
    },
    {
        maxWeight: 7.6,
        price: 38000
    },
    {
        maxWeight: 8.1,
        price: 40000
    },
    {
        maxWeight: 8.6,
        price: 43000
    },
    {
        maxWeight: 9.1,
        price: 45000
    },
    {
        maxWeight: 9.6,
        price: 48000
    },
    {
        maxWeight: 10.1,
        price: 50000
    },
    {
        maxWeight: 10.6,
        price: 53000
    },
    {
        maxWeight: 11.1,
        price: 55000
    },
    {
        maxWeight: 11.6,
        price: 58000
    },
    {
        maxWeight: 12.1,
        price: 60000
    },
    {
        maxWeight: 12.6,
        price: 63000
    },
    {
        maxWeight: 13.1,
        price: 65000
    },
    {
        maxWeight: 13.6,
        price: 68000
    },
    {
        maxWeight: 14.1,
        price: 70000
    },
    {
        maxWeight: 14.6,
        price: 73000
    },
    {
        maxWeight: 15.1,
        price: 75000
    },
    {
        maxWeight: 15.6,
        price: 78000
    },
    {
        maxWeight: 16.1,
        price: 80000
    },
    {
        maxWeight: 16.6,
        price: 83000
    },
    {
        maxWeight: 17.1,
        price: 85000
    },
    {
        maxWeight: 17.6,
        price: 88000
    },
    {
        maxWeight: 18.1,
        price: 90000
    },
    {
        maxWeight: 18.6,
        price: 93000
    },
    {
        maxWeight: 19.1,
        price: 95000
    },
    {
        maxWeight: 19.6,
        price: 98000
    },
    {
        maxWeight: 20.1,
        price: 100000
    }
]

module.exports = { WEIGHT_PRICE_LIST }